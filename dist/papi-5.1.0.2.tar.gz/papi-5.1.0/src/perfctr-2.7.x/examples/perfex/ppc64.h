#define ARCH_LONG_OPTIONS	\
    { "mmcr0", 1, NULL, 1 }, \
    { "mmcr1", 1, NULL, 2 }, \
    { "mmcra", 1, NULL, 3 },
